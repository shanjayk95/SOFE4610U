from django.urls import path
from . import views

urlpatterns = [
    path("temperatures/", views.TemperatureList.as_view())
    path("temperatures/<int:pk>", views.TemperatureDetails.as_view())
]