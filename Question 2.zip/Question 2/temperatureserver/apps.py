from django.apps import AppConfig


class TemperatureserverConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'temperatureserver'
