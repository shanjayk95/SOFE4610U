from django.db import models

# Create your models here.
class Temperature(models.Model):
    temp = models.IntegerField(default=0)
    date = models.DateField(auto_now=True)
    time = models.TimeField(auto_now=True)

    def __str__(self):
        return str(self.temp)